CREATE DATABASE estoquecomercial;


USE estoquecomercial;
CREATE TABLE Itens_Estoque(
idItem INT NOT NULL AUTO_INCREMENT,
descricaoItem VARCHAR(200),
setorItem VARCHAR(200),
precoVendaItem DOUBLE(9,2),
estoqueItem INT,
PRIMARY KEY (idItem)
);


INSERT INTO Itens_Estoque
(descricaoItem,setorItem,precoVendaItem,estoqueItem)VALUES
--('Suco de Laranja','Bebidas','7.50',250),
--('Macarrão 1kg','Alimentos','5.20',180),
--('Sabão em pó','Limpeza','12.90',90),
--('Café Torrado','Alimentos','15.80',120),
--('Iogurte Natural','Laticínios','4.30',350),
--('Biscoito Integral',NULL,'3.90',210),
--('Molho de Tomate','Alimentos','2.80',500)
('Refrigerante de Cola', 'Bebidas', '7.50', 700);

SELECT setorItem FROM Itens_Estoque
where descricaoItem = 'Molho de Tomate';

SELECT setorItem, setorItem, precoVendaItem
FROM Itens_Estoque
where descricaoItem <> 'Iogurte Natural';

select precoVendaItem, estoqueItem
from Itens_Estoque
where descricaoItem = 'Biscoito Integral ' AND setorItem is NULL

INSERT INTO Itens_Estoque
(descricaoItem,setorItem,precoVendaItem,estoqueItem)VALUES
('Refrigerante de Cola', 'Bebidas', '7.50', 700);


SELECT descricaoItem, setorItem, precoVendaItem
FROM Itens_Estoque
WHERE setorItem = 'Bebidas'
OR setorItem = 'Alimentos';


SELECT descricaoItem, setorItem, precoVendaItem
FROM Itens_Estoque
WHERE descricaoItem = 'Refrigerante de Cola'
OR precoVendaItem > 10;

select descricaoItem, setorItem, precoVendaItem
from Itens_Estoque
where precoVendaItem between 1.00 and 7.50;



select * from Itens_Estoque
where descricaoItem like '%ão%';

select(precoVendaItem * estoqueItem) AS total_multi
from Itens_Estoque;

select(precoVendaItem / estoqueItem) AS total_divi
from Itens_Estoque;

select(precoVendaItem - estoqueItem) AS total_subtra
from Itens_Estoque;

select(precoVendaItem + estoqueItem) AS total_soma
from Itens_Estoque;

select(precoVendaItem * 2) AS total_multi_por_2
from Itens_Estoque;

select precoVendaItem
from Itens_Estoque
where setorItem
in('Alimentos', 'Limpeza','Praia', 'Bebidas', 'Laticínios')
ORDER BY precoVendaItem desc;


select precoVendaItem
from Itens_Estoque
where setorItem
in('Alimentos', 'Limpeza','Praia', 'Bebidas', 'Laticínios')
ORDER BY precoVendaItem asc;

select precoVendaItem
from Itens_Estoque
where setorItem
in('Alimentos', 'Limpeza','Praia', 'Bebidas', 'Laticínios')
ORDER BY precoVendaItem, setorItem desc;

select count (descricaoItem)
from Itens_Estoque
where descricaoItem like '%Molho%';

select avg (precoVendaItem)
from Itens_Estoque;

select sum (estoqueItem)
from Itens_Estoque;

select min (precoVendaItem)
from Itens_Estoque;

select max (precoVendaItem)
from Itens_Estoque;

-- 1) Verificar quantidade de itens por setor
select setorItem, count(estoqueItem) as qtd
from ItensEstoque
GROUP BY setorItem;

-- 2) Verificar média do valor dos produtos por setor
SELECT setorItem, AVG (precoVendaItem) AS media_preco
FROM ItensEstoque
GROUP BY setorItem;

-- 3) Verificar valor mínimo e máximo por setor
SELECT setorItem,
MIN(precoVendaItem) AS menor_preco,
MAX(precoVendaItem) AS maior_preco
FROM ItensEstoque
GROUP BY setorItem;


/*
Nesse cenário, o banco de dados não consegue determinar corretamente:
Qual linha representa o resultado agregado.
Por isso: Surge a necessidade do GROUP BY.
*/

select setorItem, min (estoqueItem)



use estoquecomercial;