create database if not exists HospitalDB;
use HospitalDB;


create table Hospitais (
	id_hospital int auto_increment primary key,
    nome varchar (100) not null, 
    cidade varchar (100),
    estado char (2),
    endereco varchar (200)
);


create table Especialidades (
   id_especialidade int auto_increment primary key,
   nome varchar (100) not null unique
);


create table Medicos (
   id_medico int auto_increment primary key,
   nome varchar (100) not null,
   crm varchar (20) unique not null,
   telefone varchar (20),
   email varchar (100),
   salario decimal (10,2),
   id_especialidade int not null,
   id_hospital int not null,
   foreign key (id_especialidade)
       references Especialidades(id_especialidade),
   foreign key (id_hospital)
       references Hospitais(id_hospital)
);


create table Pacientes (
   id_paciente int auto_increment primary key,
   nome varchar (100) not null,
   cpf char (11) unique,
   data_nascimento date,
   telefone varchar (20),
   email varchar (100),
   endereco varchar (200),
   tipo_sanguineo varchar (5),
   alergias text
);


create table Convenios (
   id_convenio int auto_increment primary key,
   nome varchar (100) not null,
   telefone varchar (20),
   cobertura text
);


create table PacienteConvenio (
   id_paciente_convenio int auto_increment primary key,
   id_paciente int not null,
   id_convenio int not null,
   numero_carteira varchar (50),
   foreign key (id_paciente)
       references Pacientes(id_paciente),
   foreign key (id_convenio)
       references Convenios(id_convenio)
);


create table Consultas (
   id_consulta int auto_increment primary key,
   data_consulta datetime not null,
   diagnostico text,
   observacoes text,
   valor decimal (10,2),
   id_paciente int not null,
   id_medico int not null,
   foreign key (id_paciente)
       references Pacientes(id_paciente),
   foreign key (id_medico)
	   references Medicos(id_medico)
);


create table Medicamentos (
   id_medicamento int auto_increment primary key,
   nome varchar (100) not null,
   fabricante varchar (100),
   estoque int,
   preco decimal (10,2)
);


create table Receitas (
   id_receita int auto_increment primary key,
   id_consulta int not null,
   data_receita date,
   observacoes text,
   foreign key (id_consulta)
       references Consultas(id_consulta)
);


create table ReceitaMedicamento (
   id_receita_medicamento int auto_increment primary key,
   id_receita int not null,
   id_medicamento int not null,
   dosagem varchar (100),
   frequencia varchar (100),
   foreign key (id_receita)
       references Receitas(id_receita),
   foreign key (id_medicamento)
       references Medicamentos(id_medicamento)
);


create table Exames (
   id_exame int auto_increment primary key,
   nome varchar (100),
   resultado text,
   data_exame date,
   id_paciente int not null,
   id_medico int not null,
   foreign key (id_paciente)
       references Pacientes(id_paciente),
   foreign key (id_medico)
       references Medicos(id_medico)
);


create table Quartos (
   id_quarto int auto_increment primary key,
   numero varchar (10),
   tipo varchar (50),
   capacidade int,
   status_quarto varchar (50),
   id_hospital int not null,
   foreign key (id_hospital)
       references Hospitais(id_hospital)
);


create table Internacoes (
   id_internacao int auto_increment primary key,
   data_entrada datetime,
   data_saida datetime,
   motivo text,
   id_paciente int not null,
   id_quarto int not null,
   foreign key (id_paciente)
       references Pacientes(id_paciente),
   foreign key (id_quarto)
       references Quartos(id_quarto)
);


create table Setores (
   id_setor int auto_increment primary key,
   nome varchar (100) not null
);


create table Funcionarios (
   id_funcionario int auto_increment primary key,
   nome varchar (100),
   cpf char (11),
   cargo varchar (100),
   salario decimal (10,2),
   id_setor int not null,
   id_hospital int not null,
   foreign key (id_setor)
       references Setores(id_setor),
   foreign key (id_hospital)
       references Hospitais(id_hospital)
);


create table Pagamentos (
   id_pagamento int auto_increment primary key,
   valor decimal (10,2),
   data_pagamento date,
   forma_pagamento varchar(50),
   id_consulta int,
   foreign key (id_consulta)
       references Consultas(id_consulta)
);


create table UsuariosSistema (
   id_usuario int auto_increment primary key,
   usuario varchar (50) unique,
   senha_hash varchar (255),
   nivel_acesso varchar (50)
);


create table Logs (
   id_log int auto_increment primary key,
   acao text,
   data_log datetime,
   id_usuario int,
   foreign key (id_usuario)
       references UsuariosSistema(id_usuario)
);
