USE HospitalDB;


-- select *
-- from Pacientes;

-- select * from Pacientes
-- where tipo_sanguineo = 'O+';


SELECT Medicos.nome,
       Medicos.crm,
       Especialidades.nome,
       Hospitais.nome,
       COUNT(Consultas.id_consulta) AS total_consultas
FROM Medicos, Especialidades, Hospitais, Consultas
WHERE Medicos.id_especialidade = Especialidades.id_especialidade
AND Hospitais.id_hospital = Medicos.id_hospital
AND Consultas.id_medico = Medicos.id_medico
AND Medicos.id_hospital = 2
GROUP BY Medicos.id_medico,
         Medicos.nome,
         Medicos.crm,
         Especialidades.nome,
         Hospitais.nome;
         
select M.nome,
       M.salario,
       E.nome
from Medicos as M
join Especialidades as E
on M.id_especialidade=
   E.id_especialidade;

select M.nome,
       max(M.salario),
       E.nome,
       M.crm
from Medicos as M
join Especialidades as E
on M.id_especialidade=
   E.id_especialidade
   group by M.nome, E.nome, M.crm
   order by max(salario) desc; 

select M.nome, 
       max(M.salario),
       E.nome,
       M.telefone,
       H.nome as hp
from Medicos as M
join Especialidades as E
on M.id_especialidade=
   E.id_especialidade
join hospitais as H on M.id_medico = H.id_hospital;

-- Amanda
SELECT M.nome,P.nome,C.data_consulta
FROM Medicos AS M, Pacientes AS P, Consultas AS C
WHERE C.id_medico = M.id_medico
AND C.id_paciente = P.id_paciente;

-- Precoce
SELECT M.nome, M.email, E.nome, COUNT(C.id_consulta), M.salario
FROM Medicos AS M 
JOIN Especialidades AS E 
ON M.id_especialidade = E.id_especialidade
JOIN Consultas AS C 
ON M.id_medico = C.id_medico
GROUP BY M.id_medico;

-- Luiza
SELECT M.nome,  M.email, M.telefone, E.nome as especialidade, H.nome as Hospital, COUNT(Exames.id_exame) as Exames_solicitados
FROM Medicos as M
JOIN Especialidades AS E ON M.id_especialidade = E.id_especialidade
JOIN Hospitais AS H ON M.id_hospital = H.id_hospital
JOIN Exames ON M.id_medico = Exames.id_medico
GROUP BY M.id_medico;