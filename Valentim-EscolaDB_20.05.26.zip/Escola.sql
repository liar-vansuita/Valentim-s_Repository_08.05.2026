-- EscolaDB

CREATE DATABASE EscolaDB;
USE EscolaDB;

CREATETABLE Alunos (
    id_alunoINTPRIMARYKEY AUTO_INCREMENT,
    nomeVARCHAR(100),
    cidadeVARCHAR(100),
    idadeINT
);

CREATETABLE Cursos (
    id_cursoINTPRIMARYKEY AUTO_INCREMENT,
    nome_cursoVARCHAR(100),
    carga_horariaINT
);

CREATETABLE Matriculas (
    id_matriculaINTPRIMARYKEY AUTO_INCREMENT,
    id_alunoINT,
    id_cursoINT,
    notaDECIMAL(4,2),
    faltasINT,
FOREIGNKEY (id_aluno)REFERENCES Alunos(id_aluno),
FOREIGNKEY (id_curso)REFERENCES Cursos(id_curso)
);