-- ATIVIDADES ESCOLADB

-- ATIVIDADES BÁSICAS --

-- 1 --> Exibe a tabela Alunos (E mostra os que estão cadastrados)
select * from Alunos; 

-- 2 --> Exibe somente os nomes dos alunos
select nome from Alunos; 

-- 3 --> Exibe a tabela Cursos
select * from Cursos; 

-- 4 --> Exibe a tabela Alunos (E mostra somente os que moram em São Paulo)
select * from Alunos 
where cidade = 'São Paulo';

-- 5 --> Exibe a tabela Alunos (E mostra somente os que moram em São Paulo)
select * from Alunos x
where idade > 20;

-- 6 --> Exibe a tabela Cursos (E mostra somente os cursos onde a carga horária é maior que 50h)
select * from Cursos 
where carga_horaria > 50;

-- 7 --> Exibe a tabela Alunos (E mostra os alunos que possuem idade entre 18 e 22 anos)
select * from Alunos 
where idade between 18 and 22;

-- 8 --> Exibe a tabela Alunos (E mostra apenas os que moram em Curitiba)
select cidade from Alunos 
where cidade = 'Curitiba';

-- 9 --> Exibe a tabela Alunos (E mostra os que possuem menos de 21 anos)
select idade from Alunos 
where idade < 21;

-- 10 --> Exibe a tabela Matrículas (E mostra todas as que foram cadastradas)
select id_matricula from Matriculas; 

-- 10+ --> Exibe a tabela Matrículas (E conta a qtd {line to line} dos cadastros)
select count(*) as total_matriculas from Matriculas; 

-- 10+premium --> Exibre a tabela Matrículas (E mostraa qtd dos cadastros)
select count(id_matricula) as total_matriculas from Matriculas; 

-- ATIVIDADES INTERMEDIÁRIAS --

-- 1 --> Exibe a tabela Matriculas (E mostra os alunos com nota > 8)
select id_aluno, nota from Matriculas 
where nota > 8;

-- 2 --> Exibe uma ova tabelaa (E mostra os alunos que tiveram mais de 5 faltas)
select Alunos.id_aluno, Alunos.nome, Matriculas.faltas from Matriculas 
join Alunos on Alunos.id_aluno = Matriculas.id_aluno
where faltas > 5;

-- 3 --> Exibe a tabela Cursos (E mostra os nomes dos cursos com carga horaria = 80)
select nome_curso, carga_horaria from Cursos 
where carga_horaria = 80;

-- 4 --> Exibe a tabela Alunos (E mostra os alunnos que NÃO moram em SP)
select nome from Alunos 
where cidade != 'São Paulo';

-- 5 --> Exibe a tabela Alunos (E mostra os nomes que começam com A)
select nome from Alunos 
where nome like 'A%';

-- 6 --> Exibe a tabela Alunos (E mostra os nomes que terminam com A)
select nome from Alunos 
where nome like '%a';

-- 7 --> Exibe a tabela Cursos (E mostra os nomes que contém a palavra "Dados")
select nome_curso from Cursos 
where nome_curso like '%Dados%';

-- 8 --> Exibe a tabela Matriculas (E mostra as matriculas com nota entre 7 e 9)
select Matriculas.id_matricula, Alunos.nome, Matriculas.nota from Matriculas 
join Alunos on Alunos.id_aluno = Matriculas.id_aluno
where nota between '7' and '9';

-- 9 --> Exibe  a tabela Alunos (E mostra os alunos com idade = 20)
select nome, idade from Alunos 
where idade = 20;

-- 10 --> Exibe a tabela Cursos (E mostra os cursos com a carga horária <= 60)
select nome_curso, carga_horaria from Cursos 
where carga_horaria <= 60 ;

-- ATIVIDADES COM 'GROUP BY' --

-- 1 --> Exibe a tabela Alunos (E mostra a qtd dos mesmos nas cidades)
select cidade, count(id_aluno) as total_alunos from Alunos 
group by cidade;

-- 2 --> Exibe a tabela Alunos (E mostra a média de idade por cidade)
select cidade, avg(idade) as media_idade from Alunos
group by cidade;

-- 3 --> Exibe a tabela Matriculas (E mostra a qtd de matriculas por curso)
select nome_curso, count (id_matricula) as qtd_matriculas from Matriculas
group by nome_curso;

-- 4 --> Exibe a tabela Matriculas (E mostra a media das notas por curso)
select id_curso, avg (nota) as media_notas from Matriculas 
group by id_curso;

-- 5 --> Exibe uma tabela nova (E mostra o total de faltas agrupadas por curso)
select Cursos.nome_curso, count(faltas) as total_faltas_curso from Matriculas
join Cursos on Matriculas.id_curso = Cursos.id_curso 
group by nome_curso;

-- 6 --> Exibe uma nova tabela (E mostra a maior nota de cada curso)
select Cursos.nome_curso, max(nota) as maior_nota_curso from Matriculas
join Cursos
group by nome_curso;

-- 7 --> Exibe uma nova tabela (E mostra a menor nota de cada curso)
select Cursos.nome_curso, min(nota) as menor_nota_curso from Matriculas
join Cursos
group by nome_curso;

-- 8 --> Exibe uma nova tabela (E mostra soma total de faltas agrupadas por aluno)
SELECT Alunos.nome, SUM(Matriculas.faltas) AS total_faltas_aluno 
FROM Matriculas 
JOIN Alunos ON Matriculas.id_aluno = Alunos.id_aluno 
GROUP BY nome;

-- 9 --> Exibe a tabela Matriculas (E mostra a média de notas agrupada por aluno.)
SELECT id_aluno, AVG(nota) AS media_aluno 
FROM Matriculas 
GROUP BY id_aluno;

-- 10 --> Exibe a tabela Alunos (E mostra a qtd de alunos em cada faixa-etária)
SELECT idade, COUNT(id_aluno) AS total_por_idade 
FROM Alunos 
GROUP BY idade;

-- ATIVIDADES COM HAVING E ORDER BY --

-- 1 --> Exibe a tabela Alunos (E mostra cidadades com +2 alunos)
select cidade from Alunos
group by cidade
having count (id_aluno);

-- 2
select Cursos.nome_curso, avg(Matriculas.nota) as media_notas
from Matriculas
join Cursos on Matriculas.id_curso = Cursos.id_curso
group by Cursos.nome_curso
having avg(Matriculas.nota) > 8;

-- 3
select Cursos.nome_curso, COUNT(Matriculas.id_matricula) as total_matriculas from Matriculas 
join Cursos  on Matriculas.id_curso = Cursos.id_curso
group by Cursos.nome_curso
having COUNT(Matriculas.id_matricula) > 2;

-- 4
select Alunos.nome, sum(Matriculas.faltas) as total_faltas
from Matriculas 
join Alunos on Matriculas.id_aluno = Alunos.id_aluno
group by Alunos.nome
having sum(Matriculas.faltas) > 5;

-- 5
select Cursos.nome_curso, min(Matriculas.nota) as menor_nota
from Matriculas
join Cursos on Matriculas.id_curso = Cursos.id_curso
group by Cursos.nome_curso
having min(Matriculas.nota) > 6;

-- 6 
select nome_curso, carga_horaria
from Cursos
order by carga_horaria desc;

-- 7
select nome, idade
from Alunos
order by idade desc;

-- 8 --> 
select Cursos.nome_curso, avg(Matriculas.nota) as media_notas
from Matriculas
join Cursos on Matriculas.id_curso = Cursos.id_curso
group by Cursos.nome_curso
order by media_notas desc;

-- 9
select cidade, COUNT(id_aluno) as total_alunos
from Alunos
group by cidade
order by total_alunos desc;

-- 10
select Alunos.nome, avg(Matriculas.nota) as media_aluno
from Matriculas
join Alunos on M.id_aluno = Alunos.id_aluno
group by Alunos.nome
having avg(Matriculas.nota) > 7
order by media_aluno desc;
